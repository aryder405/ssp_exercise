This is an ASP NET CORE web application.
To run this app, you'll need to have the .NET Core 2.2 Runtime installed.
This can be found at https://dotnet.microsoft.com/download/thank-you/dotnet-runtime-2.2.5-windows-hosting-bundle-installer
Once you have the runtime installed, extract the Exercise folder to a location of your choosing.
In a terminal or command prompt, browse to the location of the folder.
Once in the Exercise folder type the commands "dotnet build" and then "dotnet run".
Then you can open your preferred browser and browse to the URL: http://localhost:60013